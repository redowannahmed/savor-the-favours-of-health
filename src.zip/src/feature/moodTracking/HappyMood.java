package feature.moodTracking;

public class HappyMood extends Mood{
    @Override
    public String getMoodName ()
    {
        return "Happy";
    }
}
