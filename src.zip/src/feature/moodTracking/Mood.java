package feature.moodTracking;

public abstract class Mood {
    public abstract String getMoodName ();
}
