package feature.moodTracking;

public class AngryMood extends Mood{
    @Override
    public String getMoodName ()
    {
        return "angry";
    }
}
