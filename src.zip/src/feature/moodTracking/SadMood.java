package feature.moodTracking;

public class SadMood extends Mood{
    @Override
    public String getMoodName ()
    {
        return "Sad";
    }
}
