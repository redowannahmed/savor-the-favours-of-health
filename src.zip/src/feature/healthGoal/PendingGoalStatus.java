package feature.healthGoal;

public class PendingGoalStatus extends GoalStatus {
    @Override
    public String getStatusName() {
        return "Pending";
    }
}
