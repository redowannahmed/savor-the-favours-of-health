package feature.healthGoal;

public class DoneGoalStatus extends GoalStatus{
    @Override
    public String getStatusName() {
        return "Done";
    }
}
