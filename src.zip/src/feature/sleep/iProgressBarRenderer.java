package feature.sleep;

public interface iProgressBarRenderer {
    String renderProgressBar(double avg, double target, int length);
}
