package feature.nutrition;

public interface iNutritionService {
    FoodItem getFoodNutrition(String foodName);
}
