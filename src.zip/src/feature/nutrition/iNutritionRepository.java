package feature.nutrition;

public interface iNutritionRepository {
    FoodItem getNutritionByName(String foodName);   
}
