package feature.aiQuery;

public interface iAIHealthQuery {
    String getAIResponse (String query);
}
