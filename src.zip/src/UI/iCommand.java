package UI;

public interface iCommand {
    void execute();
}
