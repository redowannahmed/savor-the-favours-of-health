package UI;
public interface iFeatureUI {
    String getTitle ();

    void run();
}
